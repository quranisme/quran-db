
Made by: Nadir Latif (nadir@pakjiddat.com)

1) Main features:

Provides functions for:

-Connecting to mysql server.
-Generating query strings for update,delete,insert and select. Very usefull for large inserts,updates. The query generating function can be called in a loop.
-Executing the generated query string.
-Please see the file examples/df_example.php for usage. To run the file you have to import the file data/function_cache.sql

2) Requirements

Requires php 5.3 and above.

Feel free to contact me for applying this script to your site.
