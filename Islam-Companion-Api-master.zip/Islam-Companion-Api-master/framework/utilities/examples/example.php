<?php

namespace Framework\Utilities;

require("../autoload.php");
require("ExampleClass.php");

$example_obj=new ExampleClass();
//$example_obj->AuthenticationTest();
//$example_obj->EncryptionTest();
//$example_obj->CachingTest();
//$example_obj->DatabaseTest();
//$example_obj->ExcelTest();
//$example_obj->EmailTest();
$example_obj->ErrorHandlingTest();
//$example_obj->FileSystemTest();
//$example_obj->StringTest();
//$example_obj->TemplateTest();
//$example_obj->ReflectionTest();
//$example_obj->LoggingTest();
//$example_obj->ProfilingTest();
//$example_obj->CollectionTest();
?>
